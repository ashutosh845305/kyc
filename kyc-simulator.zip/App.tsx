import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { AuthContextType, User } from './types/auth';
import { Citizen } from './types/citizen';
import { GamificationStats } from './types/verification';
import Dashboard from './components/dashboard/Dashboard';
import LoginForm from './components/auth/LoginForm';
import { login as mockLogin, logout as mockLogout } from './services/authService';
import { getFromStorage, saveToStorage } from './services/storageService';
import useSyntheticData from './hooks/useSyntheticData';

export const AuthContext = React.createContext<AuthContextType | null>(null);
export const CitizenContext = React.createContext<{ citizen: Citizen | null; nextCitizen: () => void; isLoading: boolean; }>({ citizen: null, nextCitizen: () => {}, isLoading: true });
export const GamificationContext = React.createContext<{ stats: GamificationStats; updateStats: (result: 'correct' | 'incorrect') => void; }>({ stats: { accuracy: 100, streak: 0, verifiedToday: 0, correctVerifications: 0, totalVerifications: 0 }, updateStats: () => {} });


const App: React.FC = () => {
    const [user, setUser] = useState<User | null>(() => getFromStorage<User>('user'));
    const { currentCitizen, fetchNextCitizen, isLoading } = useSyntheticData();
    const [stats, setStats] = useState<GamificationStats>(() => getFromStorage<GamificationStats>('gamificationStats') || {
        accuracy: 100,
        streak: 0,
        verifiedToday: 0,
        correctVerifications: 0,
        totalVerifications: 0
    });

    useEffect(() => {
        saveToStorage('gamificationStats', stats);
    }, [stats]);

    const login = (email: string, pass: string): boolean => {
        const loggedInUser = mockLogin(email, pass);
        if (loggedInUser) {
            setUser(loggedInUser);
            saveToStorage('user', loggedInUser);
            return true;
        }
        return false;
    };

    const logout = () => {
        mockLogout();
        setUser(null);
    };
    
    const updateStats = useCallback((result: 'correct' | 'incorrect') => {
        setStats(prevStats => {
            const newTotal = prevStats.totalVerifications + 1;
            const newCorrect = result === 'correct' ? prevStats.correctVerifications + 1 : prevStats.correctVerifications;
            const newStreak = result === 'correct' ? prevStats.streak + 1 : 0;
            const newAccuracy = newTotal > 0 ? (newCorrect / newTotal) * 100 : 100;

            return {
                totalVerifications: newTotal,
                correctVerifications: newCorrect,
                verifiedToday: prevStats.verifiedToday + 1,
                streak: newStreak,
                accuracy: newAccuracy,
            };
        });
    }, []);

    const authContextValue = useMemo(() => ({ user, login, logout }), [user]);
    const citizenContextValue = useMemo(() => ({ citizen: currentCitizen, nextCitizen: fetchNextCitizen, isLoading }), [currentCitizen, fetchNextCitizen, isLoading]);
    const gamificationContextValue = useMemo(() => ({ stats, updateStats }), [stats, updateStats]);

    return (
        <AuthContext.Provider value={authContextValue}>
            <div className="min-h-screen font-sans text-gray-900 bg-gray-100 dark:bg-gray-900 dark:text-gray-200">
                {user ? (
                    <GamificationContext.Provider value={gamificationContextValue}>
                        <CitizenContext.Provider value={citizenContextValue}>
                            <Dashboard />
                        </CitizenContext.Provider>
                    </GamificationContext.Provider>
                ) : (
                    <LoginForm />
                )}
            </div>
        </AuthContext.Provider>
    );
};

export default App;