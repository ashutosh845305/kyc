
import { Citizen, Address, Passport, UtilityBill, AnyDocument } from '../types/citizen';
import { firstNames, lastNames, middleNames, addresses, states } from '../data/mockData';
import { generatePassportSvg, generateUtilityBillSvg, generateCitizenPhoto } from './geminiService';
import { VerificationDecision } from '../types/verification';

// --- UTILITY FUNCTIONS ---
const getRandomItem = <T,>(arr: T[]): T => arr[Math.floor(Math.random() * arr.length)];
const randomDate = (start: Date, end: Date): Date => new Date(start.getTime() + Math.random() * (end.getTime() - start.getTime()));
const formatDateISO = (date: Date): string => date.toISOString().split('T')[0];
const generatePhoneNumber = (): string => {
    const areaCode = Math.floor(Math.random() * (999 - 200) + 200);
    const middle = Math.floor(Math.random() * 1000);
    const last = Math.floor(Math.random() * 10000);
    return `${String(areaCode).padStart(3, '0')}${String(middle).padStart(3, '0')}${String(last).padStart(4, '0')}`;
};
const pad = (num: number, size: number): string => String(num).padStart(size, '0');
const emailDomains = ["gmail.com", "yahoo.com", "outlook.com", "icloud.com", "aol.com", "proton.me", "mail.com"];


// --- UK NINO GENERATOR ---
const generateNINO = (): string => {
    const notAllowed = ['GB', 'BG', 'NK', 'KN', 'TN', 'NT', 'ZZ'];
    const firstAllowed = ['A', 'B', 'C', 'E', 'G', 'H', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'R', 'S', 'T', 'W', 'X', 'Y', 'Z'];
    const secondAllowed = ['A', 'B', 'C', 'E', 'G', 'H', 'J', 'K', 'L', 'M', 'N', 'P', 'R', 'S', 'T', 'W', 'X', 'Y', 'Z'];
    let group1 = '';
    while (!group1 || notAllowed.includes(group1)) {
        group1 = getRandomItem(firstAllowed) + getRandomItem(secondAllowed);
    }
    const group2 = pad(Math.floor(Math.random() * 100), 2);
    const group3 = pad(Math.floor(Math.random() * 100), 2);
    const group4 = pad(Math.floor(Math.random() * 100), 2);
    const group5 = getRandomItem(['A', 'B', 'C', 'D']);
    return `${group1}${group2}${group3}${group4}${group5}`;
};


// --- CANADIAN SIN GENERATOR ---
const generateSIN = (): string => {
    const validPrefix = [1, 2, 3, 4, 5, 6, 7, 9];
    let sin = String(getRandomItem(validPrefix));
    while (sin.length < 8) {
        sin += String(Math.floor(Math.random() * 10));
    }

    let sum = 0;
    const reversedSIN = sin.split('').reverse().join('');
    for (let i = 0; i < reversedSIN.length; i++) {
        let digit = parseInt(reversedSIN[i]);
        if (i % 2 === 0) {
            digit *= 2;
            if (digit > 9) {
                digit -= 9;
            }
        }
        sum += digit;
    }
    const checkDigit = (Math.ceil(sum / 10) * 10 - sum) % 10;
    return `${sin}${checkDigit}`;
};


// --- US SSN GENERATOR ---
const ssnStatePrefixes: Record<string, [number, number]> = {
    'AK': [574, 574], 'AL': [416, 424], 'AR': [429, 432], 'AZ': [526, 527], 'CA': [545, 573],
    'CO': [521, 524], 'CT': [45, 46], 'DC': [577, 579], 'DE': [221, 222], 'FL': [261, 267],
    'GA': [252, 260], 'HI': [575, 576], 'IA': [478, 485], 'ID': [518, 519], 'IL': [318, 361],
    'IN': [303, 317], 'KS': [509, 515], 'KY': [408, 415], 'LA': [433, 439], 'MA': [1, 34],
    'MD': [223, 231], 'ME': [35, 36], 'MI': [362, 386], 'MN': [468, 477], 'MO': [486, 500],
    'MS': [425, 428], 'MT': [516, 517], 'NC': [237, 246], 'ND': [458, 467], 'NE': [503, 508],
    'NH': [37, 38], 'NJ': [135, 158], 'NM': [525, 525], 'NV': [528, 529], 'NY': [50, 134],
    'OH': [268, 302], 'OK': [440, 448], 'OR': [531, 539], 'PA': [159, 220], 'RI': [39, 44],
    'SC': [247, 251], 'SD': [501, 502], 'TN': [408, 415], 'TX': [449, 467], 'UT': [520, 520],
    'VA': [232, 236], 'VT': [47, 49], 'WA': [531, 539], 'WI': [387, 399], 'WV': [232, 236], 'WY': [520, 520]
};

const generateSSN = (state: string): string => {
    const range = ssnStatePrefixes[state] || [700, 728]; // Default range for unlisted states
    const area = Math.floor(Math.random() * (range[1] - range[0] + 1)) + range[0];
    const group = Math.floor(Math.random() * 900) + 100;
    const serial = Math.floor(Math.random() * 9000) + 1000;
    return `${pad(area, 3)}${pad(group, 2)}${pad(serial, 4)}`;
};

const generatePassportNumber = () => Math.random().toString(36).substring(2, 11).toUpperCase();

const generateCitizenBaseData = () => {
    const firstName = getRandomItem(firstNames);
    const lastName = getRandomItem(lastNames);
    const middleName = getRandomItem(middleNames);
    const dateOfBirth = formatDateISO(randomDate(new Date(1950, 0, 1), new Date(2002, 0, 1)));
    const address = getRandomItem(addresses);
    const phone = generatePhoneNumber();
    const email = `${firstName.toLowerCase()}.${lastName.toLowerCase()}${Math.floor(Math.random() * 100)}@${getRandomItem(emailDomains)}`;

    return { firstName, lastName, middleName, dateOfBirth, address, phone, email };
};

const generatePassport = (firstName: string, lastName: string, dob: string, nationality: string): Passport => {
    const issueDate = randomDate(new Date(2018, 0, 1), new Date());
    const expirationDate = new Date(issueDate);
    expirationDate.setFullYear(expirationDate.getFullYear() + 10);

    return {
        documentType: 'Passport',
        firstName,
        lastName,
        dateOfBirth: dob,
        nationality,
        documentNumber: generatePassportNumber(),
        issueDate: formatDateISO(issueDate),
        expirationDate: formatDateISO(expirationDate),
        isValid: new Date() < expirationDate,
    };
};

const generateUtilityBill = (name: string, address: Address): UtilityBill => {
    const issueDate = randomDate(new Date(2023, 0, 1), new Date());
    const serviceStartDate = new Date(issueDate);
    serviceStartDate.setMonth(serviceStartDate.getMonth() - 1);

    return {
        documentType: 'Utility Bill',
        name,
        address,
        documentNumber: `UTIL-${Math.random().toString().slice(2, 12)}`,
        issueDate: formatDateISO(issueDate),
        servicePeriod: `${formatDateISO(serviceStartDate)} - ${formatDateISO(issueDate)}`,
        isValid: true, // Utility bills don't typically "expire" in the same way
    };
};

export const generateSyntheticCitizen = async (): Promise<Citizen> => {
    const baseInfo = generateCitizenBaseData();
    const nationality: 'United States' = 'United States'; // Simplified for now
    
    // Step 1: Generate AI photo first, as it's needed for other documents
    const photoB64 = await generateCitizenPhoto(`${baseInfo.firstName} ${baseInfo.lastName}`);

    // Step 2: Create data for documents
    const passportData = generatePassport(baseInfo.firstName, baseInfo.lastName, baseInfo.dateOfBirth, nationality);
    const utilityBillData = generateUtilityBill(`${baseInfo.firstName} ${baseInfo.lastName}`, baseInfo.address);
    
    // Step 3: Generate SVG content for documents in parallel
    const [passportSvg, utilityBillSvg] = await Promise.all([
        generatePassportSvg({ ...baseInfo, nationality }, passportData, photoB64),
        generateUtilityBillSvg({ ...baseInfo, nationality }, utilityBillData)
    ]);
    
    // Step 4: Combine data with generated SVGs
    passportData.svgContent = passportSvg;
    utilityBillData.svgContent = utilityBillSvg;

    const documents: AnyDocument[] = [passportData, utilityBillData];

    // TODO: Implement more complex scenario/flag generation logic
    const scenarioDescription = "Standard identity verification for a new bank account application. No initial red flags detected from provided information.";
    const correctVerificationDecision: VerificationDecision = 'Approve';

    return {
        id: `SYNTH_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`,
        personalInfo: {
            ...baseInfo,
            nationality: nationality,
            nationalIdentifier: generateSSN(baseInfo.address.state),
            nationalIdentifierType: 'SSN',
        },
        documents,
        riskProfile: 'low',
        complianceFlags: [],
        correctVerificationDecision,
        scenarioDescription,
    };
};
