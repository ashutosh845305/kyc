
import { GoogleGenAI, GenerateContentResponse } from "@google/genai";
import { Passport, UtilityBill, Address } from "../types/citizen";
import { formatDate } from '../utils/formatters';

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY as string });

// --- IMAGE GENERATION ---

export async function generateCitizenPhoto(fullName: string): Promise<string> {
    const prompt = `A professional, passport-style, high-resolution, color headshot of a person named ${fullName}. The person should be looking directly at the camera with a neutral expression. The background should be plain and light-colored.`;
    try {
        const response = await ai.models.generateImages({
            model: 'imagen-4.0-generate-001',
            prompt: prompt,
            config: {
                numberOfImages: 1,
                outputMimeType: 'image/jpeg',
                aspectRatio: '3:4', // Common portrait aspect ratio
            },
        });

        if (response.generatedImages && response.generatedImages.length > 0) {
            return response.generatedImages[0].image.imageBytes;
        }
        throw new Error("No image was generated.");

    } catch (error) {
        console.error("Error generating citizen photo:", error);
        // Fallback or re-throw as appropriate for your app's error handling
        return ""; // Return empty string or a placeholder base64
    }
}


// --- SVG DOCUMENT GENERATION ---

type CitizenBaseInfo = {
    firstName: string;
    lastName: string;
    middleName: string;
    dateOfBirth: string;
    nationality: string;
    address: Address;
};

function getPassportPrompt(citizen: CitizenBaseInfo, passport: Passport, photoB64: string): string {
    const nationalityDetails = {
        'United States': { countryCode: 'USA', issuingAuthority: 'United States Department of State' },
        'Canada': { countryCode: 'CAN', issuingAuthority: 'Immigration, Refugees and Citizenship Canada' },
        'United Kingdom': { countryCode: 'GBR', issuingAuthority: 'HM Passport Office' },
    };
    const details = nationalityDetails[citizen.nationality as keyof typeof nationalityDetails];

    // Machine-Readable Zone (MRZ) generation
    const formatMrzName = (lastName: string, firstName: string, middleName: string) => {
        return `${lastName.toUpperCase()}<<${firstName.toUpperCase()}<${middleName.toUpperCase()}`.replace(/ /g, '<').padEnd(39, '<');
    };
    const formatMrzDob = (dob: string) => {
        const d = new Date(dob);
        return `${String(d.getUTCFullYear()).slice(2)}${String(d.getUTCMonth() + 1).padStart(2, '0')}${String(d.getUTCDate()).padStart(2, '0')}`;
    };
    const formatMrzExpiry = (expiry: string) => {
        const d = new Date(expiry);
        return `${String(d.getUTCFullYear()).slice(2)}${String(d.getUTCMonth() + 1).padStart(2, '0')}${String(d.getUTCDate()).padStart(2, '0')}`;
    };

    const mrzLine1 = `P<${details.countryCode}${formatMrzName(citizen.lastName, citizen.firstName, citizen.middleName)}`;
    const mrzLine2 = `${passport.documentNumber.padEnd(9, '<')}1${details.countryCode}${formatMrzDob(citizen.dateOfBirth)}M${formatMrzExpiry(passport.expirationDate!)}<<<<<<<<<<<<<<4`;


    return `
    Generate a complete, single SVG file representing a realistic passport data page. Do not include any explanation, markdown, or comments. The output must be only the raw SVG code.
    The SVG should be 800px wide and 500px tall with a light grey background (#f0f2f5) and subtle watermarks.
    Use a common, clean sans-serif font like 'Arial' or 'Helvetica'.

    The passport must contain the following data:
    - Type: P
    - Code: ${details.countryCode}
    - Passport No.: ${passport.documentNumber}
    - Surname: ${citizen.lastName.toUpperCase()}
    - Given Names: ${citizen.firstName.toUpperCase()} ${citizen.middleName.toUpperCase()}
    - Nationality: ${citizen.nationality}
    - Date of Birth: ${formatDate(citizen.dateOfBirth).toUpperCase()}
    - Sex: M
    - Place of Birth: ${citizen.address.city.toUpperCase()}, ${citizen.address.state}
    - Date of Issue: ${formatDate(passport.issueDate).toUpperCase()}
    - Date of Expiry: ${formatDate(passport.expirationDate!).toUpperCase()}
    - Authority: ${details.issuingAuthority}

    Layout:
    1.  On the left, embed the citizen's photo. The image data is: "data:image/jpeg;base64,${photoB64}". The photo should be 150px wide and 200px tall.
    2.  The text data fields should be on the right, clearly labeled and organized, similar to a real passport.
        - Labels (like 'Surname') should be small and grey.
        - Values (like '${citizen.lastName.toUpperCase()}') should be larger and black.
    3.  Below the main data section, include a two-line Machine-Readable Zone (MRZ) using a monospace font like 'Courier New' or 'OCRB'.
        - Line 1: ${mrzLine1}
        - Line 2: ${mrzLine2}

    Please create a professional and clean layout.
    `;
}

function getUtilityBillPrompt(citizen: CitizenBaseInfo, bill: UtilityBill): string {
    return `
    Generate a complete, single SVG file representing a professional-looking utility bill. Do not include any explanation or markdown. The output must be only the SVG code.
    The SVG should be 600px wide and 800px tall with a white background. Use a standard business font like 'Arial'.

    The bill should look like it's from "Statewide Power & Light Co." and contain the following information:
    - Company Logo: A simple, clean logo for "Statewide Power & Light Co." in the top-left.
    - Customer Name: ${bill.name}
    - Service Address: ${bill.address.street}, ${bill.address.city}, ${bill.address.state} ${bill.address.zip}
    - Account Number: ${bill.documentNumber}
    - Bill Date: ${formatDate(bill.issueDate)}
    - Service Period: ${bill.servicePeriod}
    
    Content Details:
    1.  **Header Section:** Company name, logo, and contact information.
    2.  **Account Summary:** A boxed section with Customer Name, Address, Account Number, and Bill Date.
    3.  **Charges Breakdown:** A table with columns for 'Description', 'Rate', and 'Amount'.
        - Include a few line items like: "Electricity Usage (850 kWh)", "State Surcharge", "Grid Maintenance Fee".
        - Calculate a believable total amount (e.g., between $80 and $200).
    4.  **Payment Information:** A section detailing the "Amount Due" and "Due Date" (30 days after the bill date).
    5.  **Remittance Slip:** A detachable-looking portion at the bottom with the account number, amount due, and mailing address for payment.

    The layout should be clean, organized, and easy to read, mimicking a real corporate bill.
    `;
}


async function generateSvg(prompt: string, type: string): Promise<string> {
    try {
        const response: GenerateContentResponse = await ai.models.generateContent({
            model: "gemini-2.5-flash",
            contents: prompt,
        });
        const svgContent = response.text
            .replace(/```svg/g, '')
            .replace(/```/g, '')
            .trim();
        return svgContent;
    } catch (error) {
        console.error(`Error generating ${type} SVG with Gemini:`, error);
        return `<svg width="500" height="300" xmlns="http://www.w3.org/2000/svg"><rect width="100%" height="100%" fill="#f0f0f0" /><text x="50%" y="50%" dominant-baseline="middle" text-anchor="middle" font-family="Arial" font-size="16" fill="red">Could not load ${type} image.</text></svg>`;
    }
}

export async function generatePassportSvg(citizen: CitizenBaseInfo, passport: Passport, photoB64: string): Promise<string> {
    const prompt = getPassportPrompt(citizen, passport, photoB64);
    return generateSvg(prompt, 'passport');
}

export async function generateUtilityBillSvg(citizen: CitizenBaseInfo, bill: UtilityBill): Promise<string> {
    const prompt = getUtilityBillPrompt(citizen, bill);
    return generateSvg(prompt, 'utility bill');
}
