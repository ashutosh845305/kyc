
import { User } from '../types/auth';
import { getFromStorage, removeFromStorage, saveToStorage } from './storageService';

const MOCK_JWT_TOKEN = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkNvbXBsaWFuY2UgT2ZmaWNlciIsImlhdCI6MTUxNjIzOTAyMn0.f4aB-4J-mIeE_pERbA_2eS-zZz_4b1t8dY_5sXqE_yM';

export const login = (email: string, pass: string): User | null => {
    // Mock login: accepts any non-empty email/password
    if (email && pass) {
        const user: User = { email, name: "Ashutosh Kumar" };
        saveToStorage('user', user);
        saveToStorage('jwt_token', MOCK_JWT_TOKEN);
        return user;
    }
    return null;
};

export const logout = (): void => {
    removeFromStorage('user');
    removeFromStorage('jwt_token');
};

export const getSession = (): User | null => {
    const token = getFromStorage<string>('jwt_token');
    if (token === MOCK_JWT_TOKEN) {
        return getFromStorage<User>('user');
    }
    return null;
};
