
export const APP_NAME = "ReactComplianceBot";
export const COMPANY_NAME = "VeriSure Analytics";
