export const formatDate = (dateString: string): string => {
    return new Date(dateString).toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'long',
        day: 'numeric'
    });
};

export const formatCurrency = (amount: number): string => {
    return new Intl.NumberFormat('en-US', {
        style: 'currency',
        currency: 'USD'
    }).format(amount);
};

export const formatNationalId = (id: string, type: 'SSN' | 'SIN' | 'NINO'): string => {
    switch(type) {
        case 'SSN':
            return `***-**-${id.slice(-4)}`;
        case 'SIN':
            return `${id.slice(0, 3)} ${id.slice(3, 6)} ${id.slice(6, 9)}`;
        case 'NINO':
            // Format: QQ 12 34 56 C - we will just show it plainly for now
            return id;
        default:
            return id;
    }
};

export const formatPhone = (phone: string): string => {
    return phone.replace(/(\d{3})(\d{3})(\d{4})/, '($1) $2-$3');
};