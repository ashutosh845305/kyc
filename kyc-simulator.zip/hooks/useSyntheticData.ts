import { useState, useCallback, useEffect } from 'react';
import { Citizen } from '../types/citizen';
import { generateSyntheticCitizen } from '../services/dataGenerator';

const useSyntheticData = () => {
    const [currentCitizen, setCurrentCitizen] = useState<Citizen | null>(null);
    const [isLoading, setIsLoading] = useState<boolean>(true);

    const fetchNextCitizen = useCallback(async () => {
        setIsLoading(true);
        try {
            const citizen = await generateSyntheticCitizen();
            setCurrentCitizen(citizen);
        } catch (error) {
            console.error("Failed to generate synthetic citizen:", error);
            // Optionally set an error state to show in the UI
        } finally {
            setIsLoading(false);
        }
    }, []);

    useEffect(() => {
        fetchNextCitizen();
    }, [fetchNextCitizen]);

    return { currentCitizen, fetchNextCitizen, isLoading };
};

export default useSyntheticData;