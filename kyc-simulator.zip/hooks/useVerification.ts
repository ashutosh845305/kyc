import { useState, useCallback } from 'react';
import { VerificationCheck, VerificationDecision, VerificationState } from '../types/verification';

const initialChecklist: VerificationCheck[] = [
    { id: 'name_match', label: 'Name matches across all documents', checked: false },
    { id: 'dob_match', label: 'Date of Birth is consistent', checked: false },
    { id: 'address_match', label: 'Address is consistent and valid', checked: false },
    { id: 'doc_validity', label: 'Documents are current and not expired', checked: false },
    { id: 'photo_match', label: 'Photo appears to be of the same person (visual check)', checked: false },
    { id: 'sanctions_check', label: 'Screened against sanctions lists (simulated)', checked: false },
];

const useVerification = () => {
    const [checklist, setChecklist] = useState<VerificationCheck[]>(initialChecklist);
    const [notes, setNotes] = useState<string>('');
    const [decision, setDecision] = useState<VerificationDecision | null>(null);

    const updateChecklistItem = useCallback((id: string, checked: boolean) => {
        setChecklist(prev => prev.map(item => (item.id === id ? { ...item, checked } : item)));
    }, []);
    
    const resetVerification = useCallback(() => {
        setChecklist(initialChecklist.map(item => ({...item, checked: false})));
        setNotes('');
        setDecision(null);
    }, []);

    const state: VerificationState = { checklist, notes, decision };

    const actions = {
        updateChecklistItem,
        setNotes,
        setDecision,
        resetVerification,
    };

    return { state, actions };
};

export default useVerification;
