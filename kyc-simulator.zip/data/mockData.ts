
export const firstNames = ["James", "Mary", "John", "Patricia", "Robert", "Jennifer", "Michael", "Linda", "William", "Elizabeth", "David", "Susan", "Richard", "Jessica", "Joseph", "Sarah", "Charles", "Karen", "Thomas", "Nancy"];
export const lastNames = ["Smith", "Johnson", "Williams", "Brown", "Jones", "Garcia", "Miller", "Davis", "Rodriguez", "Martinez", "Hernandez", "Lopez", "Gonzalez", "Wilson", "Anderson", "Thomas", "Taylor", "Moore", "Jackson", "Martin"];
export const middleNames = ["Lee", "Ann", "Marie", "Jo", "Lynn", "Ray", "Allen", "Scott", "Rose", "Grace", "James", "Michael", "John", "David", "Robert", "William", "Charles", "Joseph", "Thomas", "Christopher"];

export const addresses = [
    { street: "123 Main St", city: "Anytown", state: "CA", zip: "90210" },
    { street: "456 Oak Ave", city: "Springfield", state: "IL", zip: "62704" },
    { street: "789 Pine Ln", city: "Metropolis", state: "NY", zip: "10001" },
    { street: "101 Maple Dr", city: "Gotham", state: "NJ", zip: "07002" },
    { street: "221B Baker St", city: "London", state: "OH", zip: "43140" },
    { street: "1600 Pennsylvania Ave", city: "Washington", state: "DC", zip: "20500" },
    { street: "888 Rodeo Dr", city: "Beverly Hills", state: "CA", zip: "90210" },
    { street: "350 Fifth Ave", city: "New York", state: "NY", zip: "10118" },
    { street: "177A Bleecker Street", city: "New York", state: "NY", zip: "10012" },
    { street: "1060 West Addison Street", city: "Chicago", state: "IL", zip: "60613" },
    { street: "1 Infinite Loop", city: "Cupertino", state: "CA", zip: "95014" },
    { street: "24 Beacon St", city: "Boston", state: "MA", zip: "02133" },
    { street: "300 Alamo Plaza", city: "San Antonio", state: "TX", zip: "78205" },
    { street: "1400 S Lake Shore Dr", city: "Chicago", state: "IL", zip: "60605" },
    { street: "600 E Grand Ave", city: "Chicago", state: "IL", zip: "60611" }
];

export const states = ["AL", "AK", "AZ", "AR", "CA", "CO", "CT", "DE", "FL", "GA", "HI", "ID", "IL", "IN", "IA", "KS", "KY", "LA", "ME", "MD", "MA", "MI", "MN", "MS", "MO", "MT", "NE", "NV", "NH", "NJ", "NM", "NY", "NC", "ND", "OH", "OK", "OR", "PA", "RI", "SC", "SD", "TN", "TX", "UT", "VT", "VA", "WA", "WV", "WI", "WY"];
