import React, { useContext } from 'react';
import { CitizenContext } from '../../App';
import { ComplianceFlag } from '../../types/citizen';

const getSeverityColor = (severity: 'low' | 'medium' | 'high') => {
    switch(severity) {
        case 'low': return 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300';
        case 'medium': return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300';
        case 'high': return 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300';
    }
};

const RiskAssessment: React.FC = () => {
    const context = useContext(CitizenContext);
    const citizen = context?.citizen;

    if (!citizen) return null;

    return (
        <div className="p-6 bg-white rounded-lg shadow dark:bg-gray-800">
            <h3 className="text-lg font-semibold leading-6 text-gray-900 dark:text-white">Risk Assessment</h3>
            <div className="mt-4 space-y-4">
                 <div>
                    <h4 className="font-medium text-gray-700 dark:text-gray-300">Scenario</h4>
                    <p className="mt-1 text-sm text-gray-600 dark:text-gray-400">{citizen.scenarioDescription}</p>
                </div>
                <div>
                    <h4 className="font-medium text-gray-700 dark:text-gray-300">Compliance Flags</h4>
                    {citizen.complianceFlags.length > 0 ? (
                        <ul className="mt-2 space-y-2">
                            {citizen.complianceFlags.map((flag: ComplianceFlag) => (
                                <li key={flag.code} className="p-3 rounded-md bg-gray-50 dark:bg-gray-700">
                                    <div className="flex items-center justify-between">
                                        <p className="font-medium text-gray-900 dark:text-white">{flag.code}</p>
                                        <span className={`px-2 py-1 text-xs font-semibold rounded-full ${getSeverityColor(flag.severity)}`}>
                                            {flag.severity}
                                        </span>
                                    </div>
                                    <p className="mt-1 text-sm text-gray-600 dark:text-gray-400">{flag.description}</p>
                                </li>
                            ))}
                        </ul>
                    ) : (
                        <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">No compliance flags raised.</p>
                    )}
                </div>
            </div>
        </div>
    );
};

export default RiskAssessment;
