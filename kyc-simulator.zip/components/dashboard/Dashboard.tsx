import React, { useContext } from 'react';
import { CitizenContext } from '../../App';
import Header from '../common/Header';
import LoadingSpinner from '../common/LoadingSpinner';
import ScoreDisplay from '../gamification/ScoreDisplay';
import CitizenProfile from './CitizenProfile';
import DocumentViewer from './DocumentViewer';
import RiskAssessment from './RiskAssessment';
import VerificationChecklist from './VerificationChecklist';

const Dashboard: React.FC = () => {
    const { citizen, isLoading } = useContext(CitizenContext);

    const renderContent = () => {
        if (isLoading) {
            return (
                <div className="flex items-center justify-center h-96">
                    <LoadingSpinner />
                </div>
            );
        }
        
        if (citizen) {
            return (
                <div className="space-y-6">
                    <ScoreDisplay />
                    <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
                        <div className="space-y-6 lg:col-span-2">
                            <CitizenProfile />
                            <DocumentViewer />
                            <RiskAssessment />
                        </div>
                        <div className="lg:col-span-1">
                            <VerificationChecklist />
                        </div>
                    </div>
                </div>
            );
        }

        return (
            <div className="flex items-center justify-center h-96">
                <p className="text-lg text-gray-500">Could not load citizen data. Please try refreshing.</p>
            </div>
        );
    };

    return (
        <div className="min-h-screen bg-gray-100 dark:bg-gray-900">
            <Header />
            <main className="container p-4 mx-auto max-w-7xl sm:p-6 lg:p-8">
                {renderContent()}
            </main>
        </div>
    );
};

export default Dashboard;