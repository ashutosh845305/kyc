import React, { useState, useContext, useEffect } from 'react';
import { CitizenContext } from '../../App';
import { AnyDocument } from '../../types/citizen';
import { formatDate, formatCurrency } from '../../utils/formatters';

const DocumentViewer: React.FC = () => {
    const context = useContext(CitizenContext);
    const documents = context?.citizen?.documents || [];
    const [activeTab, setActiveTab] = useState(0);

    useEffect(() => {
        // Reset to the first tab when a new citizen is loaded
        setActiveTab(0);
    }, [context?.citizen?.id]);


    if (documents.length === 0) {
        return <div className="p-6 text-center text-gray-500 bg-white rounded-lg shadow dark:bg-gray-800">No documents available.</div>;
    }
    
    const renderDocumentContent = (doc: AnyDocument) => {
        // If SVG content is available, render it directly.
        if ('svgContent' in doc && doc.svgContent) {
            // The container for SVG needs to allow overflow and maybe have a max-height
            // to handle different SVG sizes gracefully.
            return (
                <div className="p-4 overflow-x-auto bg-gray-50 dark:bg-gray-900">
                    <div 
                        className="flex items-center justify-center"
                        dangerouslySetInnerHTML={{ __html: doc.svgContent }} 
                    />
                </div>
            );
        }
        
        // Fallback to text details if no SVG is present.
        return (
            <div className="p-6">
                 <dl className="divide-y divide-gray-200 dark:divide-gray-700">
                    {Object.entries(doc).map(([key, value]) => {
                        // Don't display technical or object-based fields in the text view
                        if (key === 'documentType' || key === 'isValid' || typeof value === 'object' || key === 'svgContent') return null;
                        
                        const formattedValue = key.toLowerCase().includes('date') 
                            ? formatDate(value) 
                            : key === 'balance' 
                            ? formatCurrency(value) 
                            : value;
                            
                        const label = key.replace(/([A-Z])/g, ' $1').replace(/^./, (str) => str.toUpperCase());

                        return (
                            <div key={key} className="grid grid-cols-3 gap-4 py-2">
                                <dt className="text-sm font-medium text-gray-500 dark:text-gray-400">{label}</dt>
                                <dd className="col-span-2 text-sm text-gray-900 dark:text-white">{String(formattedValue)}</dd>
                            </div>
                        );
                    })}
                </dl>
            </div>
        )
    }


    return (
        <div className="bg-white rounded-lg shadow dark:bg-gray-800">
            <div className="border-b border-gray-200 dark:border-gray-700">
                <nav className="flex -mb-px space-x-4" aria-label="Tabs">
                    {documents.map((doc, index) => (
                        <button
                            key={doc.documentNumber}
                            onClick={() => setActiveTab(index)}
                            className={`${
                                activeTab === index
                                    ? 'border-indigo-500 text-indigo-600 dark:text-indigo-400'
                                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300 dark:text-gray-400 dark:hover:text-gray-200'
                            } whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm`}
                        >
                            {doc.documentType} {!doc.isValid && <span className="ml-2 text-xs text-red-500">(Expired)</span>}
                        </button>
                    ))}
                </nav>
            </div>
            <div>
                {documents[activeTab] ? renderDocumentContent(documents[activeTab]) : <p className="p-6">Select a document to view details.</p>}
            </div>
        </div>
    );
};

export default DocumentViewer;