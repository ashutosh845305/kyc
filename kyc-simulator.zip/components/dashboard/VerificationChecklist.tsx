import React, { useContext } from 'react';
import useVerification from '../../hooks/useVerification';
import { GamificationContext, CitizenContext } from '../../App';
import { VerificationDecision } from '../../types/verification';

const VerificationChecklist: React.FC = () => {
    const { state, actions } = useVerification();
    const gamification = useContext(GamificationContext);
    const citizenContext = useContext(CitizenContext);
    
    const handleSubmit = (decision: VerificationDecision) => {
        if (!gamification || !citizenContext || !citizenContext.citizen) return;

        const isCorrect = decision === citizenContext.citizen.correctVerificationDecision;
        gamification.updateStats(isCorrect ? 'correct' : 'incorrect');

        // Reset for next citizen
        actions.resetVerification();
        citizenContext.nextCitizen();
    };

    return (
        <div className="p-6 bg-white rounded-lg shadow dark:bg-gray-800">
            <h3 className="text-lg font-semibold leading-6 text-gray-900 dark:text-white">Verification Checklist & Decision</h3>
            <div className="mt-4 space-y-4">
                <fieldset>
                    <legend className="sr-only">Verification Checklist</legend>
                    <div className="space-y-3">
                        {state.checklist.map((item) => (
                            <div key={item.id} className="relative flex items-start">
                                <div className="flex items-center h-5">
                                    <input
                                        id={item.id}
                                        name={item.id}
                                        type="checkbox"
                                        checked={item.checked}
                                        onChange={(e) => actions.updateChecklistItem(item.id, e.target.checked)}
                                        className="w-4 h-4 text-indigo-600 border-gray-300 rounded focus:ring-indigo-500 dark:bg-gray-700 dark:border-gray-600"
                                    />
                                </div>
                                <div className="ml-3 text-sm">
                                    <label htmlFor={item.id} className="font-medium text-gray-700 dark:text-gray-300">
                                        {item.label}
                                    </label>
                                </div>
                            </div>
                        ))}
                    </div>
                </fieldset>
                
                <div>
                    <label htmlFor="notes" className="block text-sm font-medium text-gray-700 dark:text-gray-300">
                        Verification Notes
                    </label>
                    <div className="mt-1">
                        <textarea
                            id="notes"
                            name="notes"
                            rows={4}
                            className="block w-full border border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm dark:bg-gray-700 dark:border-gray-600"
                            value={state.notes}
                            onChange={(e) => actions.setNotes(e.target.value)}
                        />
                    </div>
                </div>

                <div className="flex justify-end pt-4 space-x-3 border-t border-gray-200 dark:border-gray-700">
                    <button onClick={() => handleSubmit('Approve')} className="px-4 py-2 text-sm font-medium text-white bg-green-600 rounded-md hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500">Approve</button>
                    <button onClick={() => handleSubmit('Escalate')} className="px-4 py-2 text-sm font-medium text-white bg-yellow-500 rounded-md hover:bg-yellow-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-yellow-500">Escalate</button>
                    <button onClick={() => handleSubmit('Reject')} className="px-4 py-2 text-sm font-medium text-white bg-red-600 rounded-md hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500">Reject</button>
                </div>
            </div>
        </div>
    );
};

export default VerificationChecklist;
