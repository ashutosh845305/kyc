import React, { useContext } from 'react';
import { CitizenContext } from '../../App';
import { formatDate, formatNationalId, formatPhone } from '../../utils/formatters';

const InfoRow: React.FC<{ label: string; value: string | undefined }> = ({ label, value }) => (
    <div className="grid grid-cols-3 gap-4 py-2">
        <dt className="text-sm font-medium text-gray-500 dark:text-gray-400">{label}</dt>
        <dd className="col-span-2 text-sm text-gray-900 dark:text-white">{value || 'N/A'}</dd>
    </div>
);

const CitizenProfile: React.FC = () => {
    const context = useContext(CitizenContext);
    const citizen = context?.citizen;

    if (!citizen) return null;

    const { personalInfo } = citizen;

    return (
        <div className="p-6 bg-white rounded-lg shadow dark:bg-gray-800">
            <h3 className="text-lg font-semibold leading-6 text-gray-900 dark:text-white">Citizen Profile</h3>
            <div className="mt-4 border-t border-gray-200 dark:border-gray-700">
                <dl className="divide-y divide-gray-200 dark:divide-gray-700">
                    <InfoRow label="Full Name" value={`${personalInfo.firstName} ${personalInfo.middleName} ${personalInfo.lastName}`} />
                    <InfoRow label="Nationality" value={personalInfo.nationality} />
                    <InfoRow label="Date of Birth" value={formatDate(personalInfo.dateOfBirth)} />
                    <InfoRow label={`National ID (${personalInfo.nationalIdentifierType})`} value={formatNationalId(personalInfo.nationalIdentifier, personalInfo.nationalIdentifierType)} />
                    <InfoRow label="Address" value={`${personalInfo.address.street}, ${personalInfo.address.city}, ${personalInfo.address.state} ${personalInfo.address.zip}`} />
                    <InfoRow label="Phone Number" value={formatPhone(personalInfo.phone)} />
                    <InfoRow label="Email Address" value={personalInfo.email} />
                </dl>
            </div>
        </div>
    );
};

export default CitizenProfile;