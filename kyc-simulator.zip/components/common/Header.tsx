import React from 'react';
import useAuth from '../../hooks/useAuth';
import { COMPANY_NAME } from '../../utils/constants';

const Header: React.FC = () => {
    const { user, logout } = useAuth();

    const toggleTheme = () => {
        if (document.documentElement.classList.contains('dark')) {
            document.documentElement.classList.remove('dark');
            localStorage.theme = 'light';
        } else {
            document.documentElement.classList.add('dark');
            localStorage.theme = 'dark';
        }
    };
    
    return (
        <header className="bg-white shadow-md dark:bg-gray-800">
            <div className="container px-4 py-3 mx-auto max-w-7xl sm:px-6 lg:px-8">
                <div className="flex items-center justify-between">
                    <div className="text-xl font-bold text-gray-800 dark:text-white">
                        {COMPANY_NAME}
                    </div>
                    <div className="flex items-center space-x-4">
                        <span className="hidden text-sm text-gray-600 sm:block dark:text-gray-300">Welcome, {user?.name}</span>
                         <button onClick={toggleTheme} className="p-2 text-gray-500 rounded-full hover:bg-gray-100 dark:hover:bg-gray-700 focus:outline-none">
                            <svg xmlns="http://www.w3.org/2000/svg" className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M20.354 15.354A9 9 0 018.646 3.646 9.003 9.003 0 0012 21a9.003 9.003 0 008.354-5.646z" />
                            </svg>
                        </button>
                        <button 
                            onClick={logout}
                            className="px-4 py-2 text-sm font-medium text-white bg-indigo-600 rounded-md hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
                        >
                            Logout
                        </button>
                    </div>
                </div>
            </div>
        </header>
    );
};

export default Header;
