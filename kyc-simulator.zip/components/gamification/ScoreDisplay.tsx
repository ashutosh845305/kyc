import React, { useContext } from 'react';
import { GamificationContext } from '../../App';

const StatCard: React.FC<{ label: string; value: string | number; icon: JSX.Element }> = ({ label, value, icon }) => (
    <div className="p-4 bg-white rounded-lg shadow dark:bg-gray-800">
        <div className="flex items-center">
            <div className="p-3 text-white bg-indigo-500 rounded-full">{icon}</div>
            <div className="ml-4">
                <p className="text-sm font-medium text-gray-500 truncate dark:text-gray-400">{label}</p>
                <p className="text-2xl font-semibold text-gray-900 dark:text-white">{value}</p>
            </div>
        </div>
    </div>
);

const ScoreDisplay: React.FC = () => {
    const context = useContext(GamificationContext);
    if(!context) return null;
    const { stats } = context;

    const icons = {
        accuracy: <svg xmlns="http://www.w3.org/2000/svg" className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>,
        streak: <svg xmlns="http://www.w3.org/2000/svg" className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" /></svg>,
        verifiedToday: <svg xmlns="http://www.w3.org/2000/svg" className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-6 9l2 2 4-4" /></svg>
    };

    return (
        <div className="grid grid-cols-1 gap-5 sm:grid-cols-3">
            <StatCard label="Accuracy" value={`${stats.accuracy.toFixed(1)}%`} icon={icons.accuracy} />
            <StatCard label="Current Streak" value={stats.streak} icon={icons.streak} />
            <StatCard label="Verified Today" value={stats.verifiedToday} icon={icons.verifiedToday} />
        </div>
    );
};

export default ScoreDisplay;