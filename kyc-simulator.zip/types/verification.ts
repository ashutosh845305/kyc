
export type VerificationDecision = 'Approve' | 'Reject' | 'Escalate';

export interface VerificationCheck {
    id: string;
    label: string;
    checked: boolean;
}

export interface VerificationState {
    checklist: VerificationCheck[];
    notes: string;
    decision: VerificationDecision | null;
}

export interface GamificationStats {
    accuracy: number;
    streak: number;
    verifiedToday: number;
    correctVerifications: number;
    totalVerifications: number;
}
