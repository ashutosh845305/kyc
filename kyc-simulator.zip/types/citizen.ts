import { VerificationDecision } from './verification';

export interface Address {
    street: string;
    city: string;
    state: string;
    zip: string;
}

export interface DocumentBase {
    documentType: string;
    issueDate: string;
    expirationDate?: string;
    documentNumber: string;
    isValid: boolean;
}

export interface DriverLicense extends DocumentBase {
    documentType: 'Driver\'s License';
    firstName: string;
    lastName: string;
    dateOfBirth: string;
    address: Address;
    state: string;
    svgContent?: string;
}

export interface Passport extends DocumentBase {
    documentType: 'Passport';
    firstName: string;
    lastName:string;
    dateOfBirth: string;
    nationality: string;
    svgContent?: string;
}

export interface UtilityBill extends DocumentBase {
    documentType: 'Utility Bill';
    name: string;
    address: Address;
    servicePeriod: string;
    svgContent?: string;
}

export interface BankStatement extends DocumentBase {
    documentType: 'Bank Statement';
    name: string;
    address: Address;
    accountNumber: string;
    statementDate: string;
    balance: number;
}

export type AnyDocument = DriverLicense | Passport | UtilityBill | BankStatement;

export interface ComplianceFlag {
    code: string;
    description: string;
    severity: 'low' | 'medium' | 'high';
}

export interface Citizen {
    id: string;
    personalInfo: {
        firstName: string;
        lastName: string;
        middleName: string;
        dateOfBirth: string;
        nationalIdentifier: string;
        nationalIdentifierType: 'SSN' | 'SIN' | 'NINO';
        nationality: 'United States' | 'Canada' | 'United Kingdom';
        address: Address;
        phone: string;
        email: string;
    };
    documents: AnyDocument[];
    riskProfile: 'low' | 'medium' | 'high';
    complianceFlags: ComplianceFlag[];
    correctVerificationDecision: VerificationDecision;
    scenarioDescription: string;
}
