
export interface User {
    email: string;
    name: string;
}

export interface AuthContextType {
    user: User | null;
    login: (email: string, pass: string) => boolean;
    logout: () => void;
}
